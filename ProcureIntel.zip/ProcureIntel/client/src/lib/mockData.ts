import { subDays, format } from 'date-fns';

export interface CompetitorProduct {
  id: string;
  name: string;
  category: string;
  currentPrice: number;
  lastPrice: number;
  change: number; // percentage
  competitor: string;
  lastUpdated: string;
  status: 'stable' | 'increasing' | 'decreasing';
}

export interface MarketTrend {
  date: string;
  marketAverage: number;
  ourPrice: number;
  competitorAvg: number;
}

export interface AuditLogEntry {
  id: string;
  user: string;
  action: string;
  resource: string;
  details: string;
  timestamp: string;
  severity: 'info' | 'warning' | 'critical';
}

export const COMPETITORS = ['Acme Corp', 'Globex Inc', 'Soylent Corp', 'Umbrella'];
export const CATEGORIES = ['Raw Materials', 'Components', 'Logistics', 'Services'];

const generateTrends = (): MarketTrend[] => {
  const trends: MarketTrend[] = [];
  for (let i = 30; i >= 0; i--) {
    const date = subDays(new Date(), i);
    // Random walk
    const marketAvg = 100 + Math.sin(i * 0.5) * 10 + Math.random() * 5;
    const ourPrice = 95 + Math.sin(i * 0.5) * 8 + Math.random() * 3;
    const competitorAvg = 102 + Math.sin(i * 0.5) * 12 + Math.random() * 6;
    
    trends.push({
      date: format(date, 'MMM dd'),
      marketAverage: Number(marketAvg.toFixed(2)),
      ourPrice: Number(ourPrice.toFixed(2)),
      competitorAvg: Number(competitorAvg.toFixed(2)),
    });
  }
  return trends;
};

export const mockTrends = generateTrends();

export const mockProducts: CompetitorProduct[] = [
  {
    id: 'prod-001',
    name: 'Steel Sheet 4mm',
    category: 'Raw Materials',
    currentPrice: 450.00,
    lastPrice: 440.00,
    change: 2.27,
    competitor: 'Acme Corp',
    lastUpdated: '2024-11-28T09:00:00Z',
    status: 'increasing'
  },
  {
    id: 'prod-002',
    name: 'Aluminum Alloy 6061',
    category: 'Raw Materials',
    currentPrice: 820.50,
    lastPrice: 825.00,
    change: -0.55,
    competitor: 'Globex Inc',
    lastUpdated: '2024-11-27T14:30:00Z',
    status: 'decreasing'
  },
  {
    id: 'prod-003',
    name: 'Microcontroller X8',
    category: 'Components',
    currentPrice: 4.25,
    lastPrice: 4.25,
    change: 0,
    competitor: 'Soylent Corp',
    lastUpdated: '2024-11-28T10:15:00Z',
    status: 'stable'
  },
  {
    id: 'prod-004',
    name: 'Polymer Resin Type A',
    category: 'Raw Materials',
    currentPrice: 1200.00,
    lastPrice: 1150.00,
    change: 4.35,
    competitor: 'Umbrella',
    lastUpdated: '2024-11-26T16:45:00Z',
    status: 'increasing'
  },
  {
    id: 'prod-005',
    name: 'Shipping Container 20ft',
    category: 'Logistics',
    currentPrice: 2500.00,
    lastPrice: 2800.00,
    change: -10.71,
    competitor: 'Acme Corp',
    lastUpdated: '2024-11-25T08:20:00Z',
    status: 'decreasing'
  },
  {
    id: 'prod-006',
    name: 'Industrial Lubricant',
    category: 'Services',
    currentPrice: 55.00,
    lastPrice: 54.50,
    change: 0.92,
    competitor: 'Globex Inc',
    lastUpdated: '2024-11-28T11:00:00Z',
    status: 'stable'
  }
];

export const mockAuditLogs: AuditLogEntry[] = [
  {
    id: 'log-001',
    user: 'Sarah Jenkins',
    action: 'Export Report',
    resource: 'Q3 Pricing Analysis',
    details: 'Exported to PDF',
    timestamp: '2024-11-28 11:34:22',
    severity: 'info'
  },
  {
    id: 'log-002',
    user: 'Michael Chang',
    action: 'Update Threshold',
    resource: 'Alert Settings',
    details: 'Changed variance threshold from 5% to 3%',
    timestamp: '2024-11-28 10:15:00',
    severity: 'warning'
  },
  {
    id: 'log-003',
    user: 'System',
    action: 'Data Sync',
    resource: 'External API: Bloomberg',
    details: 'Synchronization completed successfully',
    timestamp: '2024-11-28 09:00:00',
    severity: 'info'
  },
  {
    id: 'log-004',
    user: 'Admin',
    action: 'User Access',
    resource: 'User: j.doe@company.com',
    details: 'Granted "Analyst" role',
    timestamp: '2024-11-27 16:45:11',
    severity: 'critical'
  },
  {
    id: 'log-005',
    user: 'Sarah Jenkins',
    action: 'Login',
    resource: 'Session',
    details: 'Successful login from IP 192.168.1.45',
    timestamp: '2024-11-27 08:55:33',
    severity: 'info'
  }
];
