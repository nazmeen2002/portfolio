import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Users, Calendar, Phone, Quote, ExternalLink, Menu, X } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import heroImage from "@assets/generated_images/soft,_hopeful_banner_for_cancer_awareness_with_pink_ribbons_and_nature_elements.png";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// --- Form Schema ---
const contactSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type ContactFormValues = z.infer<typeof contactSchema>;

// --- Quote Interface ---
interface QuoteData {
  content: string;
  author: string;
}

export default function CancerAwareness() {
  const { toast } = useToast();
  const [quote, setQuote] = useState<QuoteData | null>(null);
  const [loadingQuote, setLoadingQuote] = useState(true);

  // --- Form Hook ---
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  // --- Fetch Quote ---
  useEffect(() => {
    const fetchQuote = async () => {
      try {
        const res = await fetch("https://api.quotable.io/random?tags=inspirational");
        if (!res.ok) throw new Error("Failed to fetch");
        const data = await res.json();
        setQuote({ content: data.content, author: data.author });
      } catch (error) {
        // Fallback if API fails
        setQuote({
          content: "Hope is the thing with feathers that perches in the soul - and sings the tune without the words - and never stops at all.",
          author: "Emily Dickinson"
        });
      } finally {
        setLoadingQuote(false);
      }
    };
    fetchQuote();
  }, []);

  // --- Submit Handler ---
  const onSubmit = (data: ContactFormValues) => {
    console.log("Form Submitted:", data);
    toast({
      title: "Message Sent",
      description: "Thank you for reaching out. We will be in touch shortly.",
    });
    form.reset();
  };

  return (
    <div className="min-h-screen bg-background font-sans text-foreground flex flex-col">
      
      {/* --- Navigation --- */}
      <nav className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary font-serif font-bold text-xl tracking-tight">
            <Heart className="w-6 h-6 fill-primary" />
            Hope & Healing
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#about" className="hover:text-primary transition-colors">About</a>
            <a href="#resources" className="hover:text-primary transition-colors">Resources</a>
            <a href="#community" className="hover:text-primary transition-colors">Community</a>
            <Button variant="default" className="rounded-full px-6 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
              Donate Now
            </Button>
          </div>

          {/* Mobile Nav */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon"><Menu className="w-5 h-5" /></Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 mt-8">
                  <a href="#about" className="text-lg font-medium">About</a>
                  <a href="#resources" className="text-lg font-medium">Resources</a>
                  <a href="#community" className="text-lg font-medium">Community</a>
                  <Button className="w-full mt-4">Donate Now</Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </nav>

      {/* --- Hero Section --- */}
      <header className="relative w-full h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={heroImage} 
            alt="Hope and Healing Banner" 
            className="w-full h-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/10 via-background/30 to-background" />
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center max-w-3xl">
          <span className="inline-block py-1 px-3 rounded-full bg-white/80 backdrop-blur-sm text-primary text-sm font-semibold mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            Together We Are Stronger
          </span>
          <h1 className="text-4xl md:text-6xl font-serif font-black text-foreground mb-6 leading-tight drop-shadow-sm animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
            Supporting Your Journey Through Awareness & Hope
          </h1>
          <p className="text-lg md:text-xl text-foreground/80 mb-8 font-light leading-relaxed animate-in fade-in slide-in-from-bottom-8 duration-700 delay-200">
            Every ribbon tells a story. Join a community dedicated to fighting cancer through early detection, patient support, and relentless hope.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300">
            <Button size="lg" className="rounded-full text-lg px-8 h-14 shadow-xl shadow-primary/20 hover:scale-105 transition-transform">
              Get Involved
            </Button>
            <Button variant="outline" size="lg" className="rounded-full text-lg px-8 h-14 bg-white/50 backdrop-blur-sm border-white/60 hover:bg-white/80">
              Learn More
            </Button>
          </div>
        </div>
      </header>

      {/* --- Quote Section (API Integration) --- */}
      <section className="py-16 bg-secondary/30 border-y border-border/50">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <Quote className="w-12 h-12 text-primary/20 mx-auto mb-6" />
          {loadingQuote ? (
            <div className="animate-pulse space-y-3">
              <div className="h-6 bg-muted rounded w-3/4 mx-auto"></div>
              <div className="h-4 bg-muted rounded w-1/4 mx-auto"></div>
            </div>
          ) : (
            <blockquote className="space-y-4">
              <p className="text-2xl md:text-3xl font-serif italic text-foreground/80 leading-relaxed">
                "{quote?.content}"
              </p>
              <footer className="text-sm font-bold tracking-widest uppercase text-primary/80">
                — {quote?.author}
              </footer>
            </blockquote>
          )}
        </div>
      </section>

      {/* --- Stats / Info Grid --- */}
      <section id="about" className="py-24 container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="border-none shadow-lg shadow-primary/5 bg-white/50 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-rose-100 rounded-2xl flex items-center justify-center mx-auto text-primary mb-4">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif font-bold">Community Support</h3>
              <p className="text-muted-foreground leading-relaxed">
                Connect with survivors, patients, and caregivers in a safe, supportive environment. You are never alone in this fight.
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-none shadow-lg shadow-primary/5 bg-white/50 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mx-auto text-teal-600 mb-4">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif font-bold">Early Detection</h3>
              <p className="text-muted-foreground leading-relaxed">
                Regular screenings save lives. Access our calendar of free local screening events and educational workshops.
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg shadow-primary/5 bg-white/50 backdrop-blur-sm hover:shadow-xl transition-shadow">
            <CardContent className="pt-8 text-center space-y-4">
              <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto text-indigo-600 mb-4">
                <Phone className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-serif font-bold">24/7 Helpline</h3>
              <p className="text-muted-foreground leading-relaxed">
                Need to talk? Our trained counselors are available day and night to provide emotional support and guidance.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* --- Contact Section --- */}
      <section id="contact" className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center max-w-6xl mx-auto">
            <div className="space-y-6">
              <h2 className="text-4xl font-serif font-bold text-foreground">Get in Touch</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Whether you need support, want to volunteer, or have a question, we're here to listen. Fill out the form and our team will get back to you.
              </p>
              <div className="space-y-4 mt-8">
                <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                  <Phone className="w-5 h-5 text-primary" />
                  <span className="font-medium">1-800-HOPE-NOW</span>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/30">
                  <ExternalLink className="w-5 h-5 text-primary" />
                  <span className="font-medium">support@hopeandhealing.org</span>
                </div>
              </div>
            </div>

            <Card className="shadow-2xl shadow-primary/10 border-muted">
              <CardContent className="p-8">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Jane Doe" {...field} className="bg-muted/30 border-muted-foreground/20 focus:bg-white transition-all" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input placeholder="jane@example.com" {...field} className="bg-muted/30 border-muted-foreground/20 focus:bg-white transition-all" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Message</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="How can we help you?" 
                              className="min-h-[120px] resize-none bg-muted/30 border-muted-foreground/20 focus:bg-white transition-all" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full h-12 text-lg font-semibold rounded-lg shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-all">
                      Send Message
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* --- Footer --- */}
      <footer className="py-12 bg-foreground text-background mt-auto">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 font-serif font-bold text-2xl mb-8 text-white">
            <Heart className="w-8 h-8 fill-primary stroke-none" />
            Hope & Healing
          </div>
          <div className="flex flex-wrap justify-center gap-8 mb-8 text-sm font-medium text-background/60">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
            <a href="#" className="hover:text-white transition-colors">Accessibility</a>
          </div>
          <p className="text-background/40 text-sm">
            © 2025 Hope & Healing Foundation. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
