import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { mockProducts, mockTrends } from "@/lib/mockData";
import { ArrowUpRight, ArrowDownRight, TrendingUp, AlertTriangle, DollarSign, Activity } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const marketAvg = mockTrends[mockTrends.length - 1].marketAverage;
  const prevMarketAvg = mockTrends[mockTrends.length - 2].marketAverage;
  const marketTrend = marketAvg > prevMarketAvg ? 'up' : 'down';
  
  const criticalItems = mockProducts.filter(p => Math.abs(p.change) > 5);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Overview of market performance and pricing alerts.</p>
      </div>

      {/* KPI Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="shadow-sm border-border/60 bg-card/50 backdrop-blur-sm hover:bg-card hover:shadow-md transition-all duration-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Market Index</CardTitle>
            <TrendingUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-display">{marketAvg.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground flex items-center mt-1">
              {marketTrend === 'up' ? (
                <span className="text-green-600 flex items-center font-medium">
                  <ArrowUpRight className="h-3 w-3 mr-1" /> +1.2%
                </span>
              ) : (
                <span className="text-red-600 flex items-center font-medium">
                  <ArrowDownRight className="h-3 w-3 mr-1" /> -0.5%
                </span>
              )}
              <span className="ml-1 opacity-70">from last month</span>
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-border/60 bg-card/50 backdrop-blur-sm hover:bg-card hover:shadow-md transition-all duration-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-display">{criticalItems.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Products with {'>'}5% variance
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-border/60 bg-card/50 backdrop-blur-sm hover:bg-card hover:shadow-md transition-all duration-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Spend</CardTitle>
            <DollarSign className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-display">$2.4M</div>
            <p className="text-xs text-muted-foreground mt-1">
              Q4 Forecast
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-border/60 bg-card/50 backdrop-blur-sm hover:bg-card hover:shadow-md transition-all duration-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Competitor Activity</CardTitle>
            <Activity className="h-4 w-4 text-indigo-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-display">High</div>
            <p className="text-xs text-muted-foreground mt-1">
              12 price changes today
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-7">
        {/* Main Chart */}
        <Card className="col-span-4 shadow-sm border-border/60">
          <CardHeader>
            <CardTitle>Market Pulse</CardTitle>
            <CardDescription>Real-time market average tracking (30 days)</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockTrends}>
                  <defs>
                    <linearGradient id="colorMarket" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `$${value}`} 
                    domain={['auto', 'auto']}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--popover))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    itemStyle={{ color: 'hsl(var(--popover-foreground))' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="marketAverage" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorMarket)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Critical Alerts List */}
        <Card className="col-span-3 shadow-sm border-border/60">
          <CardHeader>
            <CardTitle>Critical Price Shifts</CardTitle>
            <CardDescription>Products requiring immediate attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {criticalItems.length === 0 ? (
                <p className="text-sm text-muted-foreground">No critical alerts.</p>
              ) : (
                criticalItems.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 border border-border/50 hover:bg-muted/50 transition-colors">
                    <div className="space-y-1">
                      <p className="text-sm font-medium leading-none">{item.name}</p>
                      <p className="text-xs text-muted-foreground">{item.competitor}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-sm font-bold font-mono">${item.currentPrice}</p>
                      </div>
                      <Badge variant={item.change > 0 ? "destructive" : "default"} className={cn(
                        "w-16 justify-center",
                        item.change > 0 ? "bg-rose-100 text-rose-700 hover:bg-rose-200 border-rose-200" : "bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border-emerald-200"
                      )}>
                        {item.change > 0 ? '+' : ''}{item.change}%
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
