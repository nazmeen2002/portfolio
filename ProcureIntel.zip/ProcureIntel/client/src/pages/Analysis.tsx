import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { mockProducts, COMPETITORS, CATEGORIES } from "@/lib/mockData";
import { Download, Filter, ArrowUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Analysis() {
  const [searchTerm, setSearchTerm] = useState("");
  const [competitorFilter, setCompetitorFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCompetitor = competitorFilter === "all" || product.competitor === competitorFilter;
    const matchesCategory = categoryFilter === "all" || product.category === categoryFilter;
    return matchesSearch && matchesCompetitor && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Pricing Analysis</h1>
          <p className="text-muted-foreground mt-1">Detailed breakdown of competitor pricing strategies.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export Report
        </Button>
      </div>

      <Card className="shadow-sm border-border/60">
        <CardHeader className="pb-4">
          <div className="flex flex-col md:flex-row gap-4 justify-between">
            <div className="relative w-full md:w-96">
              <Filter className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Filter by product name..." 
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-4">
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={competitorFilter} onValueChange={setCompetitorFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Competitor" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Competitors</SelectItem>
                  {COMPETITORS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border border-border/50 overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="w-[250px]">Product Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Competitor</TableHead>
                  <TableHead className="text-right cursor-pointer hover:text-primary">
                    <div className="flex items-center justify-end gap-1">
                      Current Price
                      <ArrowUpDown className="w-3 h-3" />
                    </div>
                  </TableHead>
                  <TableHead className="text-right">Change (24h)</TableHead>
                  <TableHead className="text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell className="font-medium text-foreground">{product.name}</TableCell>
                    <TableCell className="text-muted-foreground">{product.category}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-background text-muted-foreground font-normal">
                        {product.competitor}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      ${product.currentPrice.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={cn(
                        "font-medium inline-flex items-center",
                        product.change > 0 ? "text-rose-600" : product.change < 0 ? "text-emerald-600" : "text-muted-foreground"
                      )}>
                        {product.change > 0 ? '+' : ''}{product.change}%
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="secondary" className={cn(
                        "w-20 justify-center font-normal",
                        product.status === 'increasing' && "bg-rose-100 text-rose-700 hover:bg-rose-200",
                        product.status === 'decreasing' && "bg-emerald-100 text-emerald-700 hover:bg-emerald-200",
                        product.status === 'stable' && "bg-slate-100 text-slate-600 hover:bg-slate-200"
                      )}>
                        {product.status.charAt(0).toUpperCase() + product.status.slice(1)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
