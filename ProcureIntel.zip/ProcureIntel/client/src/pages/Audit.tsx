import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { mockAuditLogs } from "@/lib/mockData";
import { Shield, FileDown, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Audit() {
  return (
    <div className="space-y-8">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Audit Logs</h1>
          <p className="text-muted-foreground mt-1">Security and compliance tracking system.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <FileDown className="w-4 h-4" />
          Export Logs
        </Button>
      </div>

      <Card className="shadow-sm border-border/60">
        <CardHeader className="flex flex-row items-center gap-4 bg-muted/10 border-b border-border/50">
          <div className="p-2 bg-primary/10 rounded-lg">
             <Shield className="w-6 h-6 text-primary" />
          </div>
          <div className="space-y-1">
            <CardTitle>System Activity</CardTitle>
            <CardDescription>Immutable record of all user actions and system events.</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[200px] pl-6">Timestamp</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Action</TableHead>
                <TableHead>Resource</TableHead>
                <TableHead>Details</TableHead>
                <TableHead className="text-right pr-6">Severity</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockAuditLogs.map((log) => (
                <TableRow key={log.id} className="group hover:bg-muted/30">
                  <TableCell className="pl-6 font-mono text-xs text-muted-foreground group-hover:text-foreground transition-colors">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      {log.timestamp}
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{log.user}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-normal bg-background">
                      {log.action}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">{log.resource}</TableCell>
                  <TableCell className="text-sm max-w-xs truncate" title={log.details}>
                    {log.details}
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <Badge variant={
                      log.severity === 'critical' ? 'destructive' : 
                      log.severity === 'warning' ? 'default' : 'secondary'
                    } className={cn(
                      "uppercase text-[10px] tracking-wider font-bold",
                      log.severity === 'warning' && "bg-amber-100 text-amber-700 hover:bg-amber-200 border-amber-200",
                      log.severity === 'info' && "bg-blue-50 text-blue-600 hover:bg-blue-100 border-blue-100"
                    )}>
                      {log.severity}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
